package com.example.cs360_projecttwo;

import java.util.List;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "weight")
public class Weight {
    @PrimaryKey
    public int uid;

    @ColumnInfo(name = "weight")
    public String weight;

}
