package com.example.cs360_projecttwo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class WeightItem {

    public class weight_item extends Fragment {

        private static final String ARG_PARAM1 = "param1";
        private static final String ARG_PARAM2 = "param2";
        private TextView sourceDate;
        private TextView sourceWeight;

        private String mDate;
        private String mWeight;
        private String nDate;
        private String nWeight;

        public weight_item() {

        public static weight_item newInstance(String date, String weight) {
            weight_item fragment = new weight_item();
            Bundle args = new Bundle();
            args.putString("date", date);
            args.putString("weight", weight);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                mDate = getArguments().getString("date");
                mWeight = getArguments().getString("weight");
            }
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View v = inflater.inflate(R.layout.fragment_weight_item, container, false);
            TextView date = v.findViewById(R.id.weight_history_date);
            TextView weight = v.findViewById(R.id.weight_history_value);

            date.setText(mDate);
            weight.setText(mWeight);

            return v;
        }
    }
}
