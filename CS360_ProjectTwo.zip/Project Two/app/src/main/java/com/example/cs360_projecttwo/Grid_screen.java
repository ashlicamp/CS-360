package com.example.cs360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

public class Grid_screen extends AppCompatActivity {
    private TextView mDate;
    private TextView mWeight;
    private TextView editDate;
    private TextView editWeight;
    private AppDatabase mDatabase;
    private Switch mSwitch;
    private Switch mSwitch2;
    private Switch mSwitch3;
    private Switch mSwitch4;
    private Switch mSwitch5;
    private Switch mSwitch6;
    private Switch mSwitch7;
    private Switch mSwitch8;
    private Switch mSwitch9;
    private Switch mSwitch10;
    private TextView editDateTemp;
    private TextView editWeightTemp;
    private List<WeightEntry> mListWeights;
    private List<WeightEntry> mTempList;
    private WeightEntry mWeightEntry;
    private WeightItem mWeightItem;
    private Button mLoadMore;
    private Button mDelete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_screen);

        mDatabase = AppDatabase.getInstance(getApplicationContext());
        mDate = findViewById(R.id.weight_history_date);
        mWeight = findViewById(R.id.weight_history_value);
        mSwitch = findViewById(R.id.switch1);
        mSwitch2 = findViewById(R.id.switch2);
        mSwitch3 = findViewById(R.id.switch3);
        mSwitch4 = findViewById(R.id.switch4);
        mSwitch5 = findViewById(R.id.switch5);
        mSwitch6 = findViewById(R.id.switch6);
        mSwitch7 = findViewById(R.id.switch7);
        mSwitch8 = findViewById(R.id.switch8);
        mSwitch9 = findViewById(R.id.switch9);
        mListWeights = mDatabase.getDailyWeights();
        mTempList = mListWeights;
        mLoadMore = findViewById(R.id.load_more_button);
        mDelete = findViewById(R.id.delete_button);


        if (mListWeights.size() > 0) {
            loadMultiples(mListWeights.size());
        }
    }

    // creates fragments for the list items
    void loadMultiples(int count) {
        if (count > 9) {
            mLoadMore.setEnabled(true);
        }
        for (int i = 0; i < count; i++) {
            FragmentTransaction insertFragment = getSupportFragmentManager().beginTransaction();
            mWeightEntry = mTempList.get(i);
            //mDailyWeight = mTempList.get(i);
            if (i == 0) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight1);
                editDateTemp = findViewById(R.id.date1);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch.setEnabled(true);
            }
            else if (i == 1) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight2);
                editDateTemp = findViewById(R.id.date2);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch2.setEnabled(true);
            }
            else if (i == 2) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight3);
                editDateTemp = findViewById(R.id.date3);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch3.setEnabled(true);
            }
            else if (i == 3) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight4);
                editDateTemp = findViewById(R.id.date4);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch4.setEnabled(true);
            }
            else if (i == 4) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight5);
                editDateTemp = findViewById(R.id.date5);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch5.setEnabled(true);
            }
            else if (i == 5) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight6);
                editDateTemp = findViewById(R.id.date6);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch6.setEnabled(true);
            }
            else if (i == 6) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight7);
                editDateTemp = findViewById(R.id.date7);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch7.setEnabled(true);
            }
            else if (i == 7) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight8);
                editDateTemp = findViewById(R.id.date8);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch8.setEnabled(true);
            }
            else if (i == 8) {
                String tempString = mWeightEntry.getWeight() + " lbs";
                editWeightTemp = findViewById(R.id.weight9);
                editDateTemp = findViewById(R.id.date9);
                editWeightTemp.setText(tempString);
                editDateTemp.setText(mWeightEntry.getDate());
                mSwitch9.setEnabled(true);
            }
        }
    }
    // enables up to 36 lists of 9 items
    public void loadMoreWeights(android.view.View view) {
        List<WeightEntry> subList;
        if (mTempList.get(0) == mListWeights.get(0)) {
            mTempList = mListWeights.subList(9, 17);
        }
        else if (mTempList.get(0) == mListWeights.get(9)) {
            mTempList = mListWeights.subList(18, 26);
        }
        else if (mTempList.get(0) == mListWeights.get(18)) {
            mTempList = mListWeights.subList(27, 35);
        }
        public void deleteDaily (WeightEntry daily) {
            SQLiteDatabase db = getWritableDatabase();
            db.delete(DailyTable.TABLE, DailyTable.COL_DATE +
                    " = ?", new String[] { daily.getDate() });
        }
    }
    // deletes a selected weight item
    public void deleteWeights(android.view.View view) {
        if (mSwitch.isChecked()) {
            Toast.makeText(getApplicationContext(), "Switch 1 checked", Toast.LENGTH_SHORT).show();
            mWeightEntry = mListWeights.get(0);
            mListWeights.remove(0);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch2.isChecked()) {
            mWeightEntry = mListWeights.get(1);
            mListWeights.remove(1);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch3.isChecked()) {
            mWeightEntry = mListWeights.get(2);
            mListWeights.remove(2);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch4.isChecked()) {
            mWeightEntry = mListWeights.get(3);
            mListWeights.remove(3);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch5.isChecked()) {
            mWeightEntry = mListWeights.get(4);
            mListWeights.remove(4);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch6.isChecked()) {
            mWeightEntry = mListWeights.get(5);
            mListWeights.remove(5);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch7.isChecked()) {
            mWeightEntry = mListWeights.get(6);
            mListWeights.remove(6);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch8.isChecked()) {
            mWeightEntry = mListWeights.get(7);
            mListWeights.remove(7);
            mDatabase.deleteDaily(mWeightEntry);
        }
        if (mSwitch9.isChecked()) {
            mWeightEntry = mListWeights.get(8);
            mListWeights.remove(8);
            mDatabase.deleteDaily(mWeightEntry);
        }
        // updates the list used for display after deleting item
        mTempList = mListWeights;
        loadMultiples(mListWeights.size());
    }

    // save notification settings
    public void settingsSave(android.view.View view) {
            Intent intent = new Intent(this, smsNotification.class);
        }
}