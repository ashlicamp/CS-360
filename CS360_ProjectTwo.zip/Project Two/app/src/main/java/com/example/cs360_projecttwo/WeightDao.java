package com.example.cs360_projecttwo;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface WeightDao {
    @Insert
    void insertAll(Weight... weight);

    @Delete
    void delete(Weight weight);
}
