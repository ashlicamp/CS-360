package com.example.cs360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class Add_weight extends AppCompatActivity {
    private EditText mDate;
    private EditText mWeight;
    private AppDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);
        mDate = findViewById(R.id.input_date);
        mWeight = findViewById(R.id.input_weight);
        mDatabase = AppDatabase.getInstance(getApplicationContext());
    }

    void openTitleBar(Fragment title_bar) {
        FragmentTransaction createTitleBar = getSupportFragmentManager().beginTransaction();
        createTitleBar.addToBackStack(null);
        createTitleBar.commit();
    }

    public void addWeight(android.view.View view) {
        Toast.makeText(getApplicationContext(), mDate.getText().toString() + mWeight.getText().toString(), Toast.LENGTH_LONG).show();
        String sDate = mDate.getText().toString();
        String sWeight = mWeight.getText().toString();
        WeightEntry dailyWeight = new WeightEntry(sDate, sWeight);
    }
}
