package com.example.cs360_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Database(entities = {User.class, Weight.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public AppDatabase(Context context) {

    }

    public abstract UserDao userDao();
    public abstract WeightDao weightDao();
    private static AppDatabase mDatabase;

    public static AppDatabase getInstance(Context context) {
        if (mDatabase == null) {
            mDatabase = new AppDatabase(context) {
                @NonNull
                @Override
                protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration config) {
                    return null;
                }

                @NonNull
                @Override
                protected InvalidationTracker createInvalidationTracker() {
                    return null;
                }

                @Override
                public void clearAllTables() {

                }

                @Override
                public UserDao userDao() {
                    return null;
                }

                @Override
                public WeightDao weightDao() {
                    return null;
                }
            };
        }
        return mDatabase;
    }
    private static final class DailyTable {
        private static final String TABLE = "daily_weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }
    public List<WeightEntry> getDailyWeights() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM dd, yyyy");
        List<WeightEntry> dailyWeights = new ArrayList<>();
        String sql = "select * from " + DailyTable.TABLE + " order by " + DailyTable.COL_DATE + " DESC";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()){
            do {
                WeightEntry weightEntry = new WeightEntry();
                weightEntry.setDate(cursor.getString(1));
                weightEntry.setWeight(cursor.getString(2));
                dailyWeights.add(weightEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dailyWeights;
    }

    public void deleteDaily (WeightEntry daily) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(DailyTable.TABLE, DailyTable.COL_DATE +
                " = ?", new String[] { daily.getDate() });
    }

    public boolean addWeightEntry (WeightEntry daily) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyTable.COL_WEIGHT, daily.getWeight());
        values.put(DailyTable.COL_DATE, daily.getDate());
        long id = db.insert(DailyTable.TABLE, null, values);
        daily.setId(id);
        return id != -1;
    }
}

