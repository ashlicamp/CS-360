package com.example.cs360_projecttwo;

public class WeightEntry {
    private long mId;
    private String mDate;
    private String mWeight;
    private int mSwitchId;

    public WeightEntry() {
        mSwitchId = 0;
    }

    public WeightEntry(String date, String weight) {
        mDate = date;
        mWeight = weight;
        mSwitchId = 0;
    }

    String stringId = String.valueOf(mId);
    public long getId() { return mId; }
    public void setSwitchId(int id) { mSwitchId = id; }
    public int getSwitchId() { return mSwitchId; }
    public String getDate() { return mDate; }
    public String getWeight() { return mWeight; }
    public void setDate(String date) { mDate = date; }
    public void setWeight(String weight) { mWeight = weight; }
    public void setId(long id) { mId = id; }
    public String getStringId() { return stringId; }
}